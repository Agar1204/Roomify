# Bedroom labels > 2024-11-17 1:02am
https://universe.roboflow.com/rishi-agarwal/bedroom-labels

Provided by a Roboflow user
License: CC BY 4.0

